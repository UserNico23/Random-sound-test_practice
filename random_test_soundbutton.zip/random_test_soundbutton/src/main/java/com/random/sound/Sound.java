package com.random.sound;

import playsound.Playsound;

public class Sound {

    public static void main(String[] args) {


        String filepath = "Gay Echo Voice TikTok Sound Effect.wav";

        Playsound musicObject = new Playsound();
        musicObject.playMusic(filepath);


    }


}
